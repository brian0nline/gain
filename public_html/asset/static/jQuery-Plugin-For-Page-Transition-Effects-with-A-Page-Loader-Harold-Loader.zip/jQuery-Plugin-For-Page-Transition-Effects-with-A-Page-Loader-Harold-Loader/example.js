$(function() {

    $('a').harold({
        background: '#00C8FF',
        loader: '.harold',
        padding: 2
    });

});