#Harold Loader

Harold is a page loader plugin for JQuery.